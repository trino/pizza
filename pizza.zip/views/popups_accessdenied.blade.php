<STYLE>
    .accessdenied{
        height: 500px;
        line-height: 500px;
        text-align: center;
        margin: auto;
        vertical-align: middle;
        color: white;
        font-weight: bolder;
        -webkit-text-stroke: 2px black;
        font-size: xx-large;
        background-image: linear-gradient(-45deg, white 25%, transparent 25%, transparent 50%, white 50%, white 75%, transparent 75%, transparent);
        background-size: 40px 40px;
    }

    .container-fluid{
        padding-left: 0px;
        padding-right: 0px;
        border-bottom: solid 50px #DC3545;
    }
</STYLE>
<DIV CLASS="accessdenied bg-danger">ACCESS DENIED</DIV>